import 'package:duex_lapins/features/catalog/domain/entities/product.dart';

abstract class CatalogRepository {
  Future<List<Product>> getProducts();
}
