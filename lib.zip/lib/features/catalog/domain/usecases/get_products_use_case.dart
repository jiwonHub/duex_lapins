import 'package:duex_lapins/features/catalog/domain/entities/product.dart';
import 'package:duex_lapins/features/catalog/domain/repositories/catalog_repository.dart';

class GetProductsUseCase {
  const GetProductsUseCase(this._repository);

  final CatalogRepository _repository;

  Future<List<Product>> call() => _repository.getProducts();
}
