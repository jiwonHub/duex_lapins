import 'package:duex_lapins/features/catalog/data/datasources/catalog_mock_data_source.dart';
import 'package:duex_lapins/features/catalog/domain/entities/product.dart';
import 'package:duex_lapins/features/catalog/domain/repositories/catalog_repository.dart';

class CatalogRepositoryImpl implements CatalogRepository {
  const CatalogRepositoryImpl(this._dataSource);
  final CatalogMockDataSource _dataSource;

  @override
  Future<List<Product>> getProducts() async {
    final models = await _dataSource.getProducts();
    return models.map((e) => e.toEntity()).toList(growable: false);
  }
}
