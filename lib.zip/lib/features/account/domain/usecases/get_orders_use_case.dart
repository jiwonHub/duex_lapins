import 'package:duex_lapins/features/account/domain/entities/order.dart';
import 'package:duex_lapins/features/account/domain/repositories/account_repository.dart';

class GetOrdersUseCase {
  const GetOrdersUseCase(this._repository);
  final AccountRepository _repository;
  Future<List<Order>> call() => _repository.getOrders();
}
