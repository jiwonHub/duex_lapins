import 'package:duex_lapins/features/account/domain/entities/order.dart';

abstract class AccountRepository {
  Future<List<Order>> getOrders();
}
