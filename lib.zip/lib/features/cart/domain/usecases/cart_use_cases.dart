import 'package:duex_lapins/features/cart/domain/entities/cart_item.dart';
import 'package:duex_lapins/features/cart/domain/repositories/cart_repository.dart';
import 'package:duex_lapins/features/catalog/domain/entities/product.dart';

class AddToCartUseCase {
  const AddToCartUseCase(this._repository);
  final CartRepository _repository;
  List<CartItem> call(Product product, String size, String color) =>
      _repository.add(product, size, color);
}

class UpdateCartQuantityUseCase {
  const UpdateCartQuantityUseCase(this._repository);
  final CartRepository _repository;
  List<CartItem> call(String productId, int quantity) =>
      _repository.updateQuantity(productId, quantity);
}

class RemoveCartItemUseCase {
  const RemoveCartItemUseCase(this._repository);
  final CartRepository _repository;
  List<CartItem> call(String productId) => _repository.remove(productId);
}

class ClearCartUseCase {
  const ClearCartUseCase(this._repository);
  final CartRepository _repository;
  List<CartItem> call() => _repository.clear();
}
