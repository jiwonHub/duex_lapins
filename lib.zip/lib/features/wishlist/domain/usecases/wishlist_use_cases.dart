import 'package:duex_lapins/features/wishlist/domain/repositories/wishlist_repository.dart';

class GetWishlistUseCase {
  const GetWishlistUseCase(this._repository);
  final WishlistRepository _repository;
  Set<String> call() => _repository.getIds();
}

class ToggleWishlistUseCase {
  const ToggleWishlistUseCase(this._repository);
  final WishlistRepository _repository;
  Set<String> call(String productId) => _repository.toggle(productId);
}
