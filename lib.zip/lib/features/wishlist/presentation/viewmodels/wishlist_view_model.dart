import 'package:duex_lapins/core/di/providers.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

class WishlistViewModel extends Notifier<Set<String>> {
  @override
  Set<String> build() => ref.read(getWishlistUseCaseProvider)();

  void toggle(String productId) {
    state = ref.read(toggleWishlistUseCaseProvider)(productId);
  }

  bool contains(String productId) => state.contains(productId);
}

final wishlistViewModelProvider =
    NotifierProvider<WishlistViewModel, Set<String>>(WishlistViewModel.new);
