import 'package:duex_lapins/features/auth/domain/entities/auth_user.dart';
import 'package:duex_lapins/features/auth/domain/repositories/auth_repository.dart';

class RestoreAuthSessionUseCase {
  const RestoreAuthSessionUseCase(this._repository);

  final AuthRepository _repository;

  Future<AuthUser?> call() {
    return _repository.restoreSession();
  }
}

class SignInWithKakaoUseCase {
  const SignInWithKakaoUseCase(this._repository);

  final AuthRepository _repository;

  Future<AuthUser?> call() {
    return _repository.signInWithKakao();
  }
}

class CompleteWebKakaoLoginUseCase {
  const CompleteWebKakaoLoginUseCase(this._repository);

  final AuthRepository _repository;

  Future<AuthUser?> call(String code) {
    return _repository.completeWebKakaoLogin(code);
  }
}

class SignOutUseCase {
  const SignOutUseCase(this._repository);

  final AuthRepository _repository;

  Future<void> call() {
    return _repository.signOut();
  }
}
