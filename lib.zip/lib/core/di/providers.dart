import 'package:duex_lapins/core/config/kakao_config.dart';
import 'package:duex_lapins/features/auth/data/repositories/kakao_auth_repository_impl.dart';
import 'package:duex_lapins/features/auth/domain/repositories/auth_repository.dart';
import 'package:duex_lapins/features/auth/domain/usecases/auth_use_cases.dart';
import 'package:duex_lapins/features/account/data/repositories/account_repository_impl.dart';
import 'package:duex_lapins/features/account/domain/repositories/account_repository.dart';
import 'package:duex_lapins/features/account/domain/usecases/get_orders_use_case.dart';
import 'package:duex_lapins/features/cart/data/repositories/cart_repository_impl.dart';
import 'package:duex_lapins/features/cart/domain/repositories/cart_repository.dart';
import 'package:duex_lapins/features/cart/domain/usecases/cart_use_cases.dart';
import 'package:duex_lapins/features/catalog/data/datasources/catalog_mock_data_source.dart';
import 'package:duex_lapins/features/catalog/data/repositories/catalog_repository_impl.dart';
import 'package:duex_lapins/features/catalog/domain/repositories/catalog_repository.dart';
import 'package:duex_lapins/features/catalog/domain/usecases/get_products_use_case.dart';
import 'package:duex_lapins/features/wishlist/data/repositories/wishlist_repository_impl.dart';
import 'package:duex_lapins/features/wishlist/domain/repositories/wishlist_repository.dart';
import 'package:duex_lapins/features/wishlist/domain/usecases/wishlist_use_cases.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

final catalogDataSourceProvider = Provider<CatalogMockDataSource>(
  (ref) => CatalogMockDataSourceImpl(),
);

final catalogRepositoryProvider = Provider<CatalogRepository>(
  (ref) => CatalogRepositoryImpl(ref.read(catalogDataSourceProvider)),
);

final getProductsUseCaseProvider = Provider<GetProductsUseCase>(
  (ref) => GetProductsUseCase(ref.read(catalogRepositoryProvider)),
);

final cartRepositoryProvider = Provider<CartRepository>(
  (ref) => CartRepositoryImpl(),
);

final addToCartUseCaseProvider = Provider<AddToCartUseCase>(
  (ref) => AddToCartUseCase(ref.read(cartRepositoryProvider)),
);

final updateCartQuantityUseCaseProvider = Provider<UpdateCartQuantityUseCase>(
  (ref) => UpdateCartQuantityUseCase(ref.read(cartRepositoryProvider)),
);

final removeCartItemUseCaseProvider = Provider<RemoveCartItemUseCase>(
  (ref) => RemoveCartItemUseCase(ref.read(cartRepositoryProvider)),
);

final clearCartUseCaseProvider = Provider<ClearCartUseCase>(
  (ref) => ClearCartUseCase(ref.read(cartRepositoryProvider)),
);

final accountRepositoryProvider = Provider<AccountRepository>(
  (ref) => AccountRepositoryImpl(),
);

final getOrdersUseCaseProvider = Provider<GetOrdersUseCase>(
  (ref) => GetOrdersUseCase(ref.read(accountRepositoryProvider)),
);

final wishlistRepositoryProvider = Provider<WishlistRepository>(
  (ref) => WishlistRepositoryImpl(),
);

final getWishlistUseCaseProvider = Provider<GetWishlistUseCase>(
  (ref) => GetWishlistUseCase(ref.read(wishlistRepositoryProvider)),
);

final toggleWishlistUseCaseProvider = Provider<ToggleWishlistUseCase>(
  (ref) => ToggleWishlistUseCase(ref.read(wishlistRepositoryProvider)),
);

final kakaoConfigProvider = Provider<KakaoConfig>(
  (ref) => const KakaoConfig.empty(),
);

final authRepositoryProvider = Provider<AuthRepository>(
  (ref) => KakaoAuthRepositoryImpl(ref.read(kakaoConfigProvider)),
);

final restoreAuthSessionUseCaseProvider = Provider<RestoreAuthSessionUseCase>(
  (ref) => RestoreAuthSessionUseCase(ref.read(authRepositoryProvider)),
);

final signInWithKakaoUseCaseProvider = Provider<SignInWithKakaoUseCase>(
  (ref) => SignInWithKakaoUseCase(ref.read(authRepositoryProvider)),
);

final completeWebKakaoLoginUseCaseProvider =
    Provider<CompleteWebKakaoLoginUseCase>(
  (ref) => CompleteWebKakaoLoginUseCase(ref.read(authRepositoryProvider)),
);

final signOutUseCaseProvider = Provider<SignOutUseCase>(
  (ref) => SignOutUseCase(ref.read(authRepositoryProvider)),
);

